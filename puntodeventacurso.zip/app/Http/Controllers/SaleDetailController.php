<?php

namespace App\Http\Controllers;

use App\saleDetail;
use Illuminate\Http\Request;

class SaleDetailController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\saleDetail  $saleDetail
     * @return \Illuminate\Http\Response
     */
    public function show(saleDetail $saleDetail)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\saleDetail  $saleDetail
     * @return \Illuminate\Http\Response
     */
    public function edit(saleDetail $saleDetail)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\saleDetail  $saleDetail
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, saleDetail $saleDetail)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\saleDetail  $saleDetail
     * @return \Illuminate\Http\Response
     */
    public function destroy(saleDetail $saleDetail)
    {
        //
    }
}
