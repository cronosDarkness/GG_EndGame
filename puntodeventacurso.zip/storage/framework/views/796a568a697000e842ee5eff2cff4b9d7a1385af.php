<!DOCTYPE html>
<html lang="en">



<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Sistema Punto De Venta</title>
  <!-- plugins:css -->
  <?php echo Html::style('melody/vendors/iconfonts/font-awesome/css/all.min.css'); ?>

  <?php echo Html::style('melody/vendors/css/vendor.bundle.base.css'); ?>

  <?php echo Html::style('melody/vendors/css/vendor.bundle.addons.css'); ?>

  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <?php echo Html::style('melody/css/style.css'); ?>

  <!-- endinject -->
  <link rel="shortcut icon" href="melody/images/favicon.png" />
</head>

<body>
  <div class="container-scroller">
    <div class="container-fluid page-body-wrapper full-page-wrapper">
      <div class="content-wrapper d-flex align-items-stretch auth auth-img-bg">
        <div class="row flex-grow">
          <div class="col-lg-6 d-flex align-items-center justify-content-center">
            <div class="auth-form-transparent text-left p-3">
              <div class="brand-logo">
                <img src="<?php echo e(asset('melody/images/logo.svg')); ?>" alt="logo">
              </div>
              <h4>Texvn Online</h4>
              <h6 class="font-weight-light">Descripción de la empresa.</h6>


              <?php echo $__env->yieldContent('content'); ?>


            </div>
          </div>
          <div class="col-lg-6 login-half-bg d-flex flex-row">
            <p class="text-white font-weight-medium text-center flex-grow align-self-end">Copyright &copy; 2020 Todos los derechos reservados <a href="https://www.youtube.com/channel/UCMWSlUcDJS00-5pmicciZ_w">Texvn Online</a></p>
          </div>
        </div>
      </div>
      <!-- content-wrapper ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- plugins:js -->
  <?php echo Html::script('melody/vendors/js/vendor.bundle.base.js'); ?>

  <?php echo Html::script('melody/vendors/js/vendor.bundle.addons.js'); ?>

  <!-- endinject -->
  <!-- inject:js -->
  <?php echo Html::script('melody/js/off-canvas.js'); ?>

  <?php echo Html::script('melody/js/hoverable-collapse.js'); ?>

  <?php echo Html::script('melody/js/misc.js'); ?>

  <?php echo Html::script('melody/js/settings.js'); ?>

  <?php echo Html::script('melody/js/todolist.js'); ?>

  <!-- endinject -->
</body>
</html>
<?php /**PATH C:\xampp\htdocs\puntodeventacurso\resources\views/layouts/login.blade.php ENDPATH**/ ?>