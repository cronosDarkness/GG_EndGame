
<h3>Listado de roles</h3>
<div class="form-group">
 <ul class="list-unstyled">
     <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <label>
                <?php echo Form::checkbox('roles[]', $role->id, null); ?>

                <?php echo e($role->name); ?>

                <em>(<?php echo e($role->description); ?>)</em>
            </label>
        </li>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </ul>
</div><?php /**PATH C:\xampp\htdocs\puntodeventacurso\resources\views/admin/user/_form.blade.php ENDPATH**/ ?>