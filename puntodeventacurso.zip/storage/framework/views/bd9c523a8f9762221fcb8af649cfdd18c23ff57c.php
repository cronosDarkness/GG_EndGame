
<?php $__env->startSection('title','información de producto'); ?>
<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('create'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('options'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('preference'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="page-header">
        <h3 class="page-title">
            <?php echo e($product->name); ?>

        </h3>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Panel administrador</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('products.index')); ?>">Productos</a></li>
                <li class="breadcrumb-item active" aria-current="page"><?php echo e($product->name); ?></li>
            </ol>
        </nav>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-4">
                            <div class="border-bottom text-center pb-4">

                                <img src="<?php echo e(asset('image/'.$product->image)); ?>" alt="profile" class="img-lg  mb-3" />
                                


                                <h3><?php echo e($product->name); ?></h3>
                                <div class="d-flex justify-content-between">
                                </div>
                            </div>
                            

                            <div class="py-4">
                                <p class="clearfix">
                                    <span class="float-left">
                                        Status
                                    </span>
                                    <span class="float-right text-muted">
                                        <?php echo e($product->status); ?>

                                    </span>
                                </p>
                                <p class="clearfix">
                                    <span class="float-left">
                                        Proveedor
                                    </span>
                                    <span class="float-right text-muted">
                                        <a href="<?php echo e(route('providers.show',$product->provider->id)); ?>">
                                        <?php echo e($product->provider->name); ?>

                                        </a>
                                    </span>
                                </p>
                                <p class="clearfix">
                                    <span class="float-left">
                                        Categoría
                                    </span>
                                    <span class="float-right text-muted">
                                        
                                        <a href="">
                                            <?php echo e($product->category->name); ?>

                                        </a>
                                    </span>
                                </p>
                                
                                
                            </div>

                            
                            <?php if($product->status == 'ACTIVE'): ?>
                            <a href="<?php echo e(route('change.status.products', $product)); ?>" class="btn btn-success btn-block">Activo</a>
                            <?php else: ?>
                            <a href="<?php echo e(route('change.status.products', $product)); ?>" class="btn btn-danger btn-block">Desactivado</a>
                            <?php endif; ?>
                        </div>
                        <div class="col-lg-8 pl-lg-5">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <h4>Información de producto</h4>
                                </div>
                            </div>
                            <div class="profile-feed">
                                <div class="d-flex align-items-start profile-feed-item">

                                    <div class="form-group col-md-6">
                                        <strong><i class="fab fa-product-hunt mr-1"></i> Código</strong>
                                        <p class="text-muted">
                                            <?php echo e($product->code); ?>

                                        </p>
                                        <hr>
                                        <strong><i class="fab fa-product-hunt mr-1"></i> Stock</strong>
                                        <p class="text-muted">
                                            <?php echo e($product->stock); ?>

                                        </p>
                                        <hr>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <strong>
                                            <i class="fas fa-mobile mr-1"></i>
                                            Precio de venta</strong>
                                        <p class="text-muted">
                                            <?php echo e($product->sell_price); ?>

                                        </p>
                                        <hr>
                                        <strong><i class="fas fa-envelope mr-1"></i> Código de barras</strong>
                                        <p class="text-muted">
                                            <?php echo DNS1D::getBarcodeHTML($product->code, 'EAN13');; ?>

                                        </p>
                                        <hr>
                                        
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer text-muted">
                    <a href="<?php echo e(route('products.index')); ?>" class="btn btn-primary float-right">Regresar</a>
                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo Html::script('melody/js/profile-demo.js'); ?>

<?php echo Html::script('melody/js/data-table.js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\puntodeventacurso\resources\views/admin/product/show.blade.php ENDPATH**/ ?>