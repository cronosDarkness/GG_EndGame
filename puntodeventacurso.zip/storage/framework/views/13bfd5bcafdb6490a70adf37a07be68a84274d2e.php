
<h3>Permisos especiales</h3>
<div class="form-group">
    <label><?php echo Form::radio('special', 'all-access'); ?> Acceso total</label>
    <label><?php echo Form::radio('special', 'no-access'); ?> Ningún acceso</label>
</div>

<h3>Lista de permisos</h3>
<div class="form-group">
 <ul class="list-unstyled">
     <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <label>
                <?php echo Form::checkbox('permissions[]', $permission->id, null); ?>

                <?php echo e($permission->name); ?>

                <em>(<?php echo e($permission->description); ?>)</em>
            </label>
        </li>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </ul>
</div>
<?php /**PATH C:\xampp\htdocs\puntodeventacurso\resources\views/admin/role/_form.blade.php ENDPATH**/ ?>