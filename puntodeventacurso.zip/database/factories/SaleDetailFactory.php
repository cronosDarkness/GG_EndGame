<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\saleDetail;
use Faker\Generator as Faker;

$factory->define(saleDetail::class, function (Faker $faker) {
    return [
        //
    ];
});
